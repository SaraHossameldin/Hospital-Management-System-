﻿using MySql.Data.MySqlClient;

namespace HMS.Registration
{
    public class PatientRepository : IPatientRepository
    {
        private readonly string _connectionString;

        public PatientRepository(string cs)
        {
            _connectionString = cs;
        }

        public void Add(Patient p)
        {
            using var con = new MySqlConnection(_connectionString);
            con.Open();
            string sql = @"INSERT INTO Patients
    (FirstName, LastName, Username, PasswordHash, Email, PhoneNumber, DateOfBirth, Address, Gender, BloodGroup)
    VALUES (@fn, @ln, @un, @phash, @em, @phone, @dob, @addr, @gender, @blood)";

            using var cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@fn", p.FirstName);
            cmd.Parameters.AddWithValue("@ln", p.LastName);
            cmd.Parameters.AddWithValue("@un", p.Username);
            cmd.Parameters.AddWithValue("@phash", p.PasswordHash);
            cmd.Parameters.AddWithValue("@em", p.Email);
            cmd.Parameters.AddWithValue("@phone", p.PhoneNumber);   // matches DB column
            cmd.Parameters.AddWithValue("@dob", p.DateOfBirth);
            cmd.Parameters.AddWithValue("@addr", p.Address);
            cmd.Parameters.AddWithValue("@gender", p.Gender);
            cmd.Parameters.AddWithValue("@blood", p.BloodGroup);    // matches DB column

            cmd.ExecuteNonQuery();

        }

        public Patient? GetByUsername(string username)
        {
            using var con = new MySqlConnection(_connectionString);
            con.Open();

            string sql = "SELECT * FROM Patients WHERE Username=@u";

            using var cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@u", username);

            using var r = cmd.ExecuteReader();

            if (!r.Read()) return null;

            return Map(r);
        }

        public IEnumerable<Patient> GetAll()
        {
            var list = new List<Patient>();
            using var con = new MySqlConnection(_connectionString);
            con.Open();

            string sql = "SELECT * FROM Patients";
            using var cmd = new MySqlCommand(sql, con);
            using var r = cmd.ExecuteReader();

            while (r.Read())
                list.Add(Map(r));

            return list;
        }

        public Patient? GetById(int id)
        {
            using var con = new MySqlConnection(_connectionString);
            con.Open();

            string sql = "SELECT * FROM Patients WHERE PatientID=@id";
            using var cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@id", id);

            using var r = cmd.ExecuteReader();
            return r.Read() ? Map(r) : null;
        }

        public IEnumerable<Patient> Search(string keyword)
        {
            var list = new List<Patient>();
            using var con = new MySqlConnection(_connectionString);
            con.Open();

            string sql = @"SELECT * FROM Patients 
                           WHERE FirstName LIKE @k
                           OR LastName LIKE @k
                           OR Username LIKE @k
                           OR Email LIKE @k";

            using var cmd = new MySqlCommand(sql, con);
            cmd.Parameters.AddWithValue("@k", "%" + keyword + "%");

            using var r = cmd.ExecuteReader();

            while (r.Read())
                list.Add(Map(r));

            return list;
        }

        private Patient Map(MySqlDataReader r)
        {

            return new Patient
            {
                PatientID = r.GetInt32("PatientID"),
                FirstName = r.GetString("FirstName"),
                LastName = r.GetString("LastName"),
                Username = r.GetString("Username"),
                PasswordHash = r.GetString("PasswordHash"),
                Email = r.GetString("Email"),
                PhoneNumber = r.GetString("PhoneNumber"),   // updated
                DateOfBirth = r.GetDateTime("DateOfBirth"),
                Address = r.GetString("Address"),
                Gender = r.GetString("Gender"),
                BloodGroup = r.GetString("BloodGroup")     // updated
            };

        }
    }
}



