﻿using System.Collections.Generic;

namespace HMS.Registration
{
    public interface IPatientRepository
    {
        Patient? GetByUsername(string username);
        void Add(Patient patient);
        IEnumerable<Patient> GetAll();
        Patient? GetById(int id);
        IEnumerable<Patient> Search(string keyword);
    }
}
