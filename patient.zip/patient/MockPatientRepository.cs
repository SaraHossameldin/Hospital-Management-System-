﻿using System.Collections.Generic;
using System.Linq;

namespace HMS.Registration
{
    public class MockPatientRepository : IPatientRepository
    {
        private readonly List<Patient> _patients = new();

        public void Add(Patient patient)
        {
            _patients.Add(patient);
        }

        public Patient? GetByUsername(string username)
        {
            return _patients.FirstOrDefault(p => p.Username == username);
        }

        public Patient? GetById(int id)
        {
            return _patients.FirstOrDefault(p => p.PatientID == id);
        }

        public IEnumerable<Patient> GetAll()
        {
            return _patients;
        }

        public IEnumerable<Patient> Search(string keyword)
        {
            keyword = keyword.ToLower();
            return _patients.Where(p =>
                p.FirstName.ToLower().Contains(keyword) ||
                p.LastName.ToLower().Contains(keyword) ||
                p.Username.ToLower().Contains(keyword) ||
                (p.Email != null && p.Email.ToLower().Contains(keyword))
            );
        }
    }
}
