﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace HMS
{
    partial class PatientDashboard
    {
        private System.ComponentModel.IContainer components = null;
        private Label lblWelcome;
        private Panel panelMain;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelMain = new Panel();
            lblWelcome = new Label();

            panelMain.Dock = DockStyle.Fill;
            panelMain.BackColor = Color.FromArgb(230, 245, 255);
            panelMain.Padding = new Padding(20);

            lblWelcome.Text = "Welcome to Your Dashboard!";
            lblWelcome.Font = new Font("Segoe UI", 28, FontStyle.Bold);
            lblWelcome.ForeColor = Color.FromArgb(0, 70, 140);
            lblWelcome.AutoSize = true;

            panelMain.Controls.Add(lblWelcome);
            Controls.Add(panelMain);

            this.WindowState = FormWindowState.Maximized;
            this.FormBorderStyle = FormBorderStyle.None;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "Patient Dashboard";

            // Button (keep the same name)
            Button btnLogout = new Button()
            {
                Text = "Logout",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Size = new Size(180, 50),
                BackColor = Color.Orange,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += BtnLogout_Click;

            panelMain.Controls.Add(btnLogout);

            // Center controls initially
            CenterControls(btnLogout);

            // Re-center on resize
            this.Resize += (s, e) => CenterControls(btnLogout);
        }

        // Helper method to center label and button
        private void CenterControls(Button btnLogout)
        {
            // Center label
            lblWelcome.Location = new Point(
                (this.ClientSize.Width - lblWelcome.PreferredWidth) / 2,
                (this.ClientSize.Height - lblWelcome.PreferredHeight) / 2 - 40
            );

            // Center button below label
            btnLogout.Location = new Point(
                (this.ClientSize.Width - btnLogout.Width) / 2,
                lblWelcome.Bottom + 70
            );
        }
    }
}

