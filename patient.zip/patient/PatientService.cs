﻿using System.Collections.Generic;

namespace HMS.Registration
{
    public class PatientService
    {
        private readonly IPatientRepository _repo;
        public PatientService(IPatientRepository repo) => _repo = repo;

        public void Register(Patient patient) => _repo.Add(patient);
        public Patient? GetById(int id) => _repo.GetById(id);
        public Patient? GetByUsername(string username) => _repo.GetByUsername(username);
        public IEnumerable<Patient> GetAll() => _repo.GetAll();

        // Add this method
        public IEnumerable<Patient> Search(string keyword) => _repo.Search(keyword);
    }
}
