﻿using HMS.Helpers;
using HMS.Login_Story;
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS
{
    public partial class PatientRegistrationForm : Form
    {
        private readonly AuthService _auth;

        public PatientRegistrationForm(AuthService auth)
        {
            _auth = auth;
            InitializeComponent();
            this.WindowState = FormWindowState.Maximized;
        }

        private async void btnRegister_Click(object sender, EventArgs e)
        {
            // Read patient input
            string firstName = txtFirstName.Text.Trim();
            string lastName = txtLastName.Text.Trim();
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
            DateTime dob = dtpDateOfBirth.Value.Date;
            string gender = cbGender.SelectedItem?.ToString() ?? "Other";
            string contact = txtContact.Text.Trim();
            string email = txtEmail.Text.Trim();
            string address = txtAddress.Text.Trim();
            string bloodGroup = txtBloodGroup.Text.Trim();

            // Validate password
            if (!Validation.IsPasswordStrong(password))
            {
                lblStatus.Text = "Password must be at least 6 characters";
                return;
            }

            // Call AuthService
            var result = _auth.RegisterPatient(
                firstName,
                lastName,
                username,
                password,
                dob,
                gender,
                contact,
                email,
                address,
                bloodGroup
            );

            if (result.Success)
            {
                lblStatus.Text = "Patient registered successfully";
                await Task.Delay(800);
                this.Close();
            }
            else
            {
                lblStatus.Text = "Error: " + result.Message;
            }
        }
    }
}
