﻿using HMS.Admin_Functionalities;
using HMS.Login_Story;
using HMS.Registration;
using System;
using System.Drawing;
using System.Windows.Forms;

namespace HMS
{
    public partial class PatientDashboard : Form
    {
        private readonly Patient _patient;
        private readonly AuthService _auth;
        private readonly PatientService _patientService;
        private readonly StaffService _staffService;
        private Button btnLogout;

        public PatientDashboard(Patient patient, AuthService auth, PatientService patientService, StaffService staffService)
        {
            InitializeComponent();

            _patient = patient;
            _auth = auth;
            _patientService = patientService;
            _staffService = staffService;

            // Full-screen and style
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(230, 245, 255); // soft light blue
            this.Text = $"Patient Dashboard - {_patient.Username}";

            // Welcome label
            lblWelcome.Text = $"Welcome, {_patient.Username}!";
            lblWelcome.Font = new Font("Segoe UI", 28, FontStyle.Bold);
            lblWelcome.ForeColor = Color.FromArgb(0, 70, 140);
            lblWelcome.AutoSize = true;
            CenterLabel();

            this.Resize += (s, e) => CenterLabel();

            // Logout button
            btnLogout = new Button()
            {
                Text = "Logout",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Size = new Size(160, 50),
                BackColor = Color.Orange,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnLogout.FlatAppearance.BorderSize = 0;
            btnLogout.Click += BtnLogout_Click;
            btnLogout.MouseEnter += (s, e) => btnLogout.BackColor = Color.DarkOrange;
            btnLogout.MouseLeave += (s, e) => btnLogout.BackColor = Color.Orange;

            this.Controls.Add(btnLogout);

            PositionLogoutButton();
            this.Resize += (s, e) => PositionLogoutButton();
        }

        private void CenterLabel()
        {
            lblWelcome.Location = new Point(
                (this.ClientSize.Width - lblWelcome.PreferredWidth) / 2,
                (this.ClientSize.Height - lblWelcome.PreferredHeight) / 2
            );
        }

        private void PositionLogoutButton()
        {
            btnLogout.Location = new Point(
                (this.ClientSize.Width - btnLogout.Width) / 2,
                this.ClientSize.Height - btnLogout.Height - 50
            );
        }

        private void BtnLogout_Click(object sender, EventArgs e)
        {
            this.Hide();
            using var loginForm = new LoginForm(_auth, _patientService, _staffService);
            loginForm.ShowDialog();
            this.Close();
        }
    }
}


