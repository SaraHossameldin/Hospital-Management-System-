﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace HMS
{
    partial class StaffActivationForm
    {
        private System.ComponentModel.IContainer components = null;

        private Label lblTitle;
        private Label lblStaffID;
        private Label lblUsername;
        private Label lblPassword;
        private TextBox txtStaffID;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnActivate;
        private Panel panelMain;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();

            // Main panel (full form background)
            panelMain = new Panel()
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(230, 245, 255) // light soothing blue
            };

            // Title Label
            lblTitle = new Label()
            {
                Text = "Activate Staff Account",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 70, 140),
                AutoSize = false,
                TextAlign = ContentAlignment.MiddleCenter,
                Dock = DockStyle.Top,
                Height = 80
            };

            // Labels
            lblStaffID = new Label()
            {
                Text = "Staff ID:",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 70, 140),
                AutoSize = true
            };
            lblUsername = new Label()
            {
                Text = "Username:",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 70, 140),
                AutoSize = true
            };
            lblPassword = new Label()
            {
                Text = "Password:",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 70, 140),
                AutoSize = true
            };

            // TextBoxes
            txtStaffID = new TextBox() { Font = new Font("Segoe UI", 12), Width = 250 };
            txtUsername = new TextBox() { Font = new Font("Segoe UI", 12), Width = 250 };
            txtPassword = new TextBox() { Font = new Font("Segoe UI", 12), Width = 250, PasswordChar = '*' };

            // Activate Button
            btnActivate = new Button()
            {
                Text = "Activate",
                Font = new Font("Segoe UI", 12, FontStyle.Bold),
                Size = new Size(150, 45),
                BackColor = Color.MediumSeaGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat
            };
            btnActivate.FlatAppearance.BorderSize = 0;
            btnActivate.Click += btnActivate_Click;
            btnActivate.MouseEnter += (s, e) => btnActivate.BackColor = Color.SeaGreen;
            btnActivate.MouseLeave += (s, e) => btnActivate.BackColor = Color.MediumSeaGreen;

            // Center controls vertically and horizontally
            int startY = 100;
            int spacing = 50;
            int centerX = 450 / 2;

            lblStaffID.Location = new Point(centerX - 200, startY);
            txtStaffID.Location = new Point(centerX - 50, startY - 5);

            lblUsername.Location = new Point(centerX - 200, startY + spacing);
            txtUsername.Location = new Point(centerX - 50, startY + spacing - 5);

            lblPassword.Location = new Point(centerX - 200, startY + spacing * 2);
            txtPassword.Location = new Point(centerX - 50, startY + spacing * 2 - 5);

            btnActivate.Location = new Point(centerX - 75, startY + spacing * 3 + 10);

            // Add controls to panel
            panelMain.Controls.Add(lblTitle);
            panelMain.Controls.Add(lblStaffID);
            panelMain.Controls.Add(txtStaffID);
            panelMain.Controls.Add(lblUsername);
            panelMain.Controls.Add(txtUsername);
            panelMain.Controls.Add(lblPassword);
            panelMain.Controls.Add(txtPassword);
            panelMain.Controls.Add(btnActivate);

            // Add panel to form
            Controls.Add(panelMain);

            // Form properties
            Text = "Staff Activation";
            ClientSize = new Size(450, 350);
            StartPosition = FormStartPosition.CenterScreen;
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
        }
    }
}
