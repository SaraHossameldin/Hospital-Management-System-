﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace HMS
{
    partial class PatientRegistrationForm
    {
        private System.ComponentModel.IContainer components = null;

        private TextBox txtFirstName, txtLastName, txtUsername, txtPassword, txtContact, txtEmail, txtAddress, txtBloodGroup;
        private DateTimePicker dtpDateOfBirth;
        private ComboBox cbGender;
        private Button btnRegister;
        private Label lblStatus, lblTitle, lblFirstName, lblLastName, lblUsername, lblPassword, lblDOB, lblGender, lblContact, lblEmail, lblAddress, lblBloodGroup;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();

            // Form properties
            BackColor = Color.FromArgb(240, 248, 255); // subtle light blue
            ClientSize = new Size(800, 750);
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Patient Registration";

            // Title
            lblTitle = new Label()
            {
                Text = "Patient Registration",
                Font = new Font("Segoe UI", 24, FontStyle.Bold),
                ForeColor = Color.FromArgb(0, 70, 140),
                Width = this.ClientSize.Width,
                Height = 60,
                TextAlign = ContentAlignment.MiddleCenter,
                Location = new Point(0, 20)
            };

            int labelWidth = 200;
            int textBoxWidth = 400; // wider for full text visibility
            int controlHeight = 30;
            int spacingY = 15;
            int startX = (this.ClientSize.Width - textBoxWidth) / 2;
            int currentY = 100;

            // Helper function to create labels
            Label CreateLabel(string text)
            {
                return new Label()
                {
                    Text = text,
                    Font = new Font("Segoe UI", 12, FontStyle.Bold),
                    ForeColor = Color.FromArgb(0, 70, 140),
                    Size = new Size(labelWidth, controlHeight),
                    TextAlign = ContentAlignment.MiddleRight
                };
            }

            // First Name
            lblFirstName = CreateLabel("First Name:");
            lblFirstName.Location = new Point(startX - labelWidth, currentY);
            txtFirstName = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Last Name
            lblLastName = CreateLabel("Last Name:");
            lblLastName.Location = new Point(startX - labelWidth, currentY);
            txtLastName = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Username
            lblUsername = CreateLabel("Username:");
            lblUsername.Location = new Point(startX - labelWidth, currentY);
            txtUsername = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Password
            lblPassword = CreateLabel("Password:");
            lblPassword.Location = new Point(startX - labelWidth, currentY);
            txtPassword = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11), PasswordChar = '*' };
            currentY += controlHeight + spacingY;

            // Date of Birth
            lblDOB = CreateLabel("Date of Birth:");
            lblDOB.Location = new Point(startX - labelWidth, currentY);
            dtpDateOfBirth = new DateTimePicker() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Gender
            lblGender = CreateLabel("Gender:");
            lblGender.Location = new Point(startX - labelWidth, currentY);
            cbGender = new ComboBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), DropDownStyle = ComboBoxStyle.DropDownList, Font = new Font("Segoe UI", 11) };
            cbGender.Items.AddRange(new object[] { "Male", "Female", "Other" });
            currentY += controlHeight + spacingY;

            // Contact
            lblContact = CreateLabel("Contact Info:");
            lblContact.Location = new Point(startX - labelWidth, currentY);
            txtContact = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Email
            lblEmail = CreateLabel("Email:");
            lblEmail.Location = new Point(startX - labelWidth, currentY);
            txtEmail = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Address
            lblAddress = CreateLabel("Address:");
            lblAddress.Location = new Point(startX - labelWidth, currentY);
            txtAddress = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY;

            // Blood Group
            lblBloodGroup = CreateLabel("Blood Group:");
            lblBloodGroup.Location = new Point(startX - labelWidth, currentY);
            txtBloodGroup = new TextBox() { Size = new Size(textBoxWidth, controlHeight), Location = new Point(startX, currentY), Font = new Font("Segoe UI", 11) };
            currentY += controlHeight + spacingY + 10;

            // Register Button
            btnRegister = new Button()
            {
                Text = "Register",
                Size = new Size(180, 50),
                Location = new Point(startX + (textBoxWidth - 180) / 2, currentY),
                BackColor = Color.MediumSeaGreen,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btnRegister.FlatAppearance.BorderSize = 0;
            btnRegister.Click += btnRegister_Click;
            btnRegister.MouseEnter += (s, e) => btnRegister.BackColor = Color.SeaGreen;
            btnRegister.MouseLeave += (s, e) => btnRegister.BackColor = Color.MediumSeaGreen;

            // Status label
            lblStatus = new Label()
            {
                Size = new Size(this.ClientSize.Width, 30),
                Location = new Point(0, currentY + 70),
                ForeColor = Color.Red,
                TextAlign = ContentAlignment.MiddleCenter
            };

            // Add controls
            Controls.Add(lblTitle);
            Controls.Add(lblFirstName); Controls.Add(txtFirstName);
            Controls.Add(lblLastName); Controls.Add(txtLastName);
            Controls.Add(lblUsername); Controls.Add(txtUsername);
            Controls.Add(lblPassword); Controls.Add(txtPassword);
            Controls.Add(lblDOB); Controls.Add(dtpDateOfBirth);
            Controls.Add(lblGender); Controls.Add(cbGender);
            Controls.Add(lblContact); Controls.Add(txtContact);
            Controls.Add(lblEmail); Controls.Add(txtEmail);
            Controls.Add(lblAddress); Controls.Add(txtAddress);
            Controls.Add(lblBloodGroup); Controls.Add(txtBloodGroup);
            Controls.Add(btnRegister);
            Controls.Add(lblStatus);
        }
    }
}
