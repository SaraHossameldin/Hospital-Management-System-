﻿using HMS.Registration;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS
{
    public partial class PatientDetailsForm : Form
    {
        private readonly Patient _patient;
        public PatientDetailsForm(Patient patient)
        {
            _patient = patient;
            InitializeComponent();
            lblUsername.Text = _patient.Username;
            lblContact.Text = _patient.PhoneNumber;  // updated
            this.WindowState = FormWindowState.Maximized;
        }
    }
}
