﻿using HMS.Admin_Functionalities;
using System;
using System.Windows.Forms;

namespace HMS
{
    public partial class StaffActivationForm : Form
    {
        private readonly StaffService _staffService;

        public StaffActivationForm(StaffService staffService, int? staffId = null)
        {
            InitializeComponent();
            _staffService = staffService;
            this.Load += StaffActivationForm_Load;

            // Clear all fields
            txtStaffID.Clear();
            txtUsername.Clear();
            txtPassword.Clear();

            // Only prefill if staffId is positive
            if (staffId.HasValue && staffId.Value > 0)
            {
                var staff = _staffService.GetById(staffId.Value);
                if (staff != null)
                {
                    txtStaffID.Text = staff.StaffID.ToString();
                    txtUsername.Text = staff.Username;
                }
            }
        }

        private void btnActivate_Click(object sender, EventArgs e)
        {
            if (!int.TryParse(txtStaffID.Text.Trim(), out int id))
            {
                MessageBox.Show("Invalid ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password required", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var staff = _staffService.GetById(id);
            if (staff == null || staff.Username != username)
            {
                MessageBox.Show("Staff not found", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            var result = _staffService.Activate(id, username, password);
            if (result.Success)
            {
                MessageBox.Show("Staff activated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            else
            {
                MessageBox.Show(result.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void ClearForm()
        {
            txtStaffID.Clear();
            txtUsername.Clear();
            txtPassword.Clear();
        }
        private void StaffActivationForm_Load(object sender, EventArgs e)
        {
            ClearForm();
        }

    }
}

